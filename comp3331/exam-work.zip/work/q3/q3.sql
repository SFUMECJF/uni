-- COMP3311 20T3 Final Exam
-- Q3: team(s) with most players who have never scored a goal

... helpers go here ...

create or replace view Q3(team,nplayers)
as
...put your SQL here...
;

