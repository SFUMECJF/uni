psql footy -c "select * from q4('France','Australia');"
