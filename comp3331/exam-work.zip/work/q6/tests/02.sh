./q6  France  2000
