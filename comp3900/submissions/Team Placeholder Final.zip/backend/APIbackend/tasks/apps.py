from django.apps import AppConfig

# Don't touch this.
# Automatically generated code
class TasksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tasks'
